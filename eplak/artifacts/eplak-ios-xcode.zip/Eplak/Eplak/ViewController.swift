import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
    private var webView: WKWebView!

    /// اگر اپ روی سرور منتشر شده، آدرس را اینجا بگذارید تا از سرور لود شود
    /// مثال: "https://eplak.example.com/index.html"
    private let serverURL: String? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.02, green: 0.04, blue: 0.08, alpha: 1)
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: view.bounds, configuration: cfg)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        view.addSubview(webView)

        if let s = serverURL, let url = URL(string: s) {
            webView.load(URLRequest(url: url))
        } else {
            let base = Bundle.main.resourceURL!.appendingPathComponent("www")
            webView.loadFileURL(base.appendingPathComponent("index.html"), allowingReadAccessTo: base)
        }
    }
}

extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
}
