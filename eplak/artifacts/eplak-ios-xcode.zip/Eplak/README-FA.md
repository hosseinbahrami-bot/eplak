# ساخت فایل IPA اپلیکیشن ای‌پلاک (iOS)

این بسته، پروژهٔ کامل Xcode است که همان نسخهٔ وب (PWA) را داخل WebView نمایش می‌دهد.

## مراحل ساخت IPA (فقط روی مک امکان‌پذیر است — نیازمند Xcode)

1. پوشه را باز کنید و `Eplak.xcodeproj` را با Xcode (نسخه ۱۵ به بالا) باز کنید.
2. از منوی **Product → Archive** بزنید.
3. در پنجرهٔ Organizer روی **Distribute App** کلیک کنید.
4. اگر فقط برای تست روی گوشی خودتان است: **Development**؛ برای تستفلايت: **TestFlight**؛ برای اپ‌استور: **App Store**.
5. خروجی، همان فایل `Eplak.ipa` است.

## امضا (Signing)
- در Xcode → target «Eplak» → Signing & Capabilities → **Team** را انتخاب کنید (اکانت رایگان Apple ID هم برای تست روی گوشی خودتان کافی است).
- Bundle Identifier فعلی: `com.example.eplakfixed` — اگر تیم توسعه دارید، بهتر است تغییرش دهید.

## بارگذاری از سرور (اختیاری)
اگر اپ را روی هاست منتشر کرده‌اید و می‌خواهید اپ از سرور لود شود:
در `Eplak/ViewController.swift` مقدار `serverURL` را قرار دهید، مثال:
```swift
private let serverURL: String? = "https://your-domain.com/index.html"
```
## آیکون
آیکون برنامه: در Xcode راست‌کلیک روی پوشهٔ Eplak → Add Files → یک Asset Catalog با AppIcon بسازید و در Build Settings مقدار ASSETCATALOG_COMPILER_APPICON_NAME را ست کنید.
